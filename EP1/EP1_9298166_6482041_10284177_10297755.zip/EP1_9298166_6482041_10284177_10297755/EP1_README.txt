Andre Ferrari Moukarzel - 9298166
Arthur Vieira Barbosa - 6482041
Gabriel Sarti Massukado - 10284177
Matheus Lima Cunha - 10297755
